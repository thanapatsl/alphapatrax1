
import React, { useState, useEffect } from 'react';
import { Page, CustomerIndexItem } from './types';
import Dashboard from './components/Dashboard';
import StatementView from './components/StatementView';
import { Storage } from './utils/storage';

const App: React.FC = () => {
  const [currentPage, setCurrentPage] = useState<Page>('dashboard');
  const [selectedCustomerId, setSelectedCustomerId] = useState<string | null>(null);
  const [customers, setCustomers] = useState<CustomerIndexItem[]>([]);
  const [totalSystemBalance, setTotalSystemBalance] = useState(0);

  const refreshData = () => {
    Storage.seedInitialData();
    const index = Storage.getCustomersIndex();
    setCustomers(index);

    let total = 0;
    index.forEach(item => {
      const details = Storage.getCustomerDetails(item.id);
      if (details && details.transactions.length > 0) {
        total += details.transactions[details.transactions.length - 1].balance;
      }
    });
    setTotalSystemBalance(total);
  };

  useEffect(() => {
    refreshData();
  }, []);

  const navigateToStatement = (id: string) => {
    setSelectedCustomerId(id);
    setCurrentPage('statement');
    window.scrollTo(0, 0);
  };

  const navigateToDashboard = () => {
    setCurrentPage('dashboard');
    setSelectedCustomerId(null);
    refreshData();
    window.scrollTo(0, 0);
  };

  const handleAddNewCustomer = () => {
    const newId = Date.now().toString();
    const newCustomer = Storage.createEmptyCustomer(newId, 'ลูกค้าใหม่');
    Storage.saveCustomerDetails(newId, newCustomer);
    navigateToStatement(newId);
  };

  const handleDeleteCustomer = (id: string) => {
    if (confirm('ยืนยันการลบข้อมูลลูกค้ารายนี้?')) {
      Storage.deleteCustomer(id);
      navigateToDashboard();
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#F8FAFC]">
      <main className="flex-grow">
        {currentPage === 'dashboard' ? (
          <Dashboard 
            customers={customers} 
            totalBalance={totalSystemBalance}
            onSelectCustomer={navigateToStatement} 
            onAddCustomer={handleAddNewCustomer}
          />
        ) : (
          <StatementView 
            customerId={selectedCustomerId} 
            onBack={navigateToDashboard} 
            onDelete={handleDeleteCustomer}
          />
        )}
      </main>

      <footer className="bg-white border-t border-gray-100 py-8 px-6 no-print">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="text-gray-400 text-xs font-medium uppercase tracking-widest">
            &copy; {new Date().getFullYear()} AlphaPatra Investment Team
          </div>
          <div className="flex space-x-6">
            <span className="text-[#6B7280] text-xs">Official Platform v2.5</span>
            <span className="text-[#6B7280] text-xs">Security Encrypted</span>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default App;
