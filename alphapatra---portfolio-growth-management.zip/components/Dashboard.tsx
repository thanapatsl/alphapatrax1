
import React, { useMemo, useState, useEffect, useRef } from 'react';
import { CustomerIndexItem, Transaction, DetailedCustomer } from '../types';
import { Storage } from '../utils/storage';
import { CSVUtils } from '../utils/csv';

declare const Chart: any;

interface DashboardProps {
  customers: CustomerIndexItem[];
  totalBalance: number;
  onSelectCustomer: (id: string) => void;
  onAddCustomer: () => void;
}

const Dashboard: React.FC<DashboardProps> = ({ customers, totalBalance, onSelectCustomer, onAddCustomer }) => {
  const [showOverview, setShowOverview] = useState(false);
  const [selectedMonth, setSelectedMonth] = useState(new Date().getMonth() + 1);
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear() + 543);
  const [isMobile, setIsMobile] = useState(window.innerWidth <= 768);
  const [logo, setLogo] = useState(Storage.getSystemLogo());
  const logoInputRef = useRef<HTMLInputElement>(null);
  const chartRef = useRef<HTMLCanvasElement>(null);
  const chartInstance = useRef<any>(null);

  useEffect(() => {
    const handleResize = () => setIsMobile(window.innerWidth <= 768);
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const months = ["ม.ค.", "ก.พ.", "มี.ค.", "เม.ย.", "พ.ค.", "มิ.ย.", "ก.ค.", "ส.ค.", "ก.ย.", "ต.ค.", "พ.ย.", "ธ.ค."];
  const fullMonths = ["มกราคม", "กุมภาพันธ์", "มิถุนายน", "เมษายน", "พฤษภาคม", "มิถุนายน", "กรกฎาคม", "สิงหาคม", "กันยายน", "ตุลาคม", "พฤศจิกายน", "ธันวาคม"];
  const years = Array.from({ length: 5 }, (_, i) => new Date().getFullYear() + 543 - i);

  const allCustomerDetails = useMemo(() => {
    return customers.map(c => Storage.getCustomerDetails(c.id)).filter(Boolean) as DetailedCustomer[];
  }, [customers]);

  const totalFund = useMemo(() => {
    return allCustomerDetails.reduce((sum, c) => sum + (c.transactions.reduce((s, t) => s + t.deposit, 0) || 0), 0);
  }, [allCustomerDetails]);

  const totalNetProfit = totalBalance - totalFund;

  const monthlyProfit = useMemo(() => {
    const targetYearCE = selectedYear - 543;
    let profit = 0;
    allCustomerDetails.forEach(customer => {
      customer.transactions.forEach((tx, idx) => {
        const txDate = new Date(tx.date);
        if (txDate.getMonth() + 1 === selectedMonth && txDate.getFullYear() === targetYearCE) {
          const prevBalance = idx === 0 ? 0 : customer.transactions[idx - 1].balance;
          profit += prevBalance * (tx.profitPercent / 100);
        }
      });
    });
    return profit;
  }, [allCustomerDetails, selectedMonth, selectedYear]);

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const base64 = event.target?.result as string;
      Storage.saveSystemLogo(base64);
      setLogo(base64);
    };
    reader.readAsDataURL(file);
  };

  useEffect(() => {
    if (showOverview && chartRef.current && allCustomerDetails.length > 0) {
      if (chartInstance.current) chartInstance.current.destroy();
      const labels = allCustomerDetails.map(c => c.name);
      const balances = allCustomerDetails.map(c => c.transactions[c.transactions.length - 1]?.balance || 0);
      const profits = allCustomerDetails.map(c => {
        const fund = c.transactions.reduce((s, t) => s + t.deposit, 0) || 0;
        const last = c.transactions[c.transactions.length - 1]?.balance || 0;
        return last - fund;
      });
      const rois = allCustomerDetails.map(c => {
        const fund = c.transactions.reduce((s, t) => s + t.deposit, 0) || 0;
        const last = c.transactions[c.transactions.length - 1]?.balance || 0;
        return fund > 0 ? ((last - fund) / fund) * 100 : 0;
      });

      chartInstance.current = new Chart(chartRef.current, {
        type: 'bar',
        data: {
          labels,
          datasets: [
            { label: 'มูลค่าพอร์ตรวมล่าสุด', data: balances, backgroundColor: '#6ce1b0', borderRadius: 4, order: 2 },
            { label: 'กำไรสุทธิ', data: profits, backgroundColor: '#a5a4f7', borderRadius: 4, order: 2 },
            { 
              label: 'ผลตอบแทน (%)', 
              data: rois, 
              type: 'line', 
              borderColor: '#f97316', 
              backgroundColor: '#f97316', 
              borderWidth: 3, 
              tension: 0, 
              pointRadius: 4, 
              yAxisID: 'y1', 
              order: 1 
            }
          ]
        },
        options: { 
          responsive: true, 
          maintainAspectRatio: false,
          plugins: { 
            legend: { 
              position: 'bottom',
              labels: { 
                usePointStyle: true,
                pointStyle: 'rectRounded',
                font: { family: 'Sarabun', size: 12, weight: '500' },
                padding: 20
              } 
            },
            tooltip: {
               bodyFont: { family: 'Sarabun' },
               titleFont: { family: 'Sarabun' }
            }
          },
          scales: { 
            x: { 
              grid: { display: false },
              ticks: { font: { family: 'Sarabun', size: 10 }, maxRotation: 45, minRotation: 45 }
            },
            y: { 
              position: 'left',
              title: { display: true, text: 'มูลค่า (บาท)', font: { family: 'Sarabun' } },
              ticks: { font: { family: 'Sarabun' } },
              grid: { color: '#f1f1f1' }
            },
            y1: { 
              position: 'right',
              title: { display: true, text: 'ผลตอบแทน (%)', font: { family: 'Sarabun' } },
              ticks: { font: { family: 'Sarabun' } },
              grid: { display: false }
            }
          } 
        }
      });
    }
  }, [showOverview, allCustomerDetails]);

  return (
    <div className="max-w-[1280px] mx-auto p-6 md:p-10 space-y-10 animate-in fade-in duration-500">
      {/* Dashboard Header with Clickable Logo */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div className="flex items-center gap-4">
          <div 
            onClick={() => !isMobile && logoInputRef.current?.click()}
            className="w-14 h-14 bg-[#064e3b] rounded-2xl flex items-center justify-center shadow-lg p-2.5 cursor-pointer hover:opacity-90 transition-opacity overflow-hidden"
            title="คลิกเพื่อเปลี่ยนโลโก้"
          >
             <img 
               src={logo} 
               alt="AlphaPatra Logo" 
               className="w-full h-full object-contain rounded-lg"
               onError={(e) => {
                 (e.target as HTMLImageElement).src = '/assets/logo/ap-logo.png';
               }}
             />
             <input 
               type="file" 
               ref={logoInputRef} 
               className="hidden" 
               accept="image/*" 
               onChange={handleLogoUpload} 
             />
          </div>
          <div>
            <h1 className="text-2xl md:text-3xl font-bold text-gray-800 tracking-tight">ระบบจัดการลูกค้าปั้นพอร์ต AlphaPatra</h1>
            <p className="text-sm text-gray-400 font-medium tracking-wider uppercase">PORTFOLIO MANAGEMENT SYSTEM</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <button 
            onClick={() => setShowOverview(true)}
            className="bg-[#8b5cf6] hover:bg-[#7c3aed] text-white px-6 py-3 rounded-xl font-bold text-sm shadow-md transition-all flex items-center gap-2"
          >
            <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
            สรุปภาพรวมลูกค้าทั้งหมด
          </button>
          <button 
            onClick={onAddCustomer}
            className="bg-[#22c55e] hover:bg-[#16a34a] text-white px-6 py-3 rounded-xl font-bold text-sm shadow-md transition-all flex items-center gap-2"
          >
            <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" /></svg>
            เพิ่มลูกค้าใหม่
          </button>
        </div>
      </div>

      {/* Summary Badges */}
      <div className="flex items-center gap-4 text-sm font-bold">
        <div className="flex items-center gap-2">
          <span className="text-[#4338ca]">ยอดรวมทุกบัญชี:</span>
          <div className="bg-[#3b82f6] text-white px-5 py-2.5 rounded-full shadow-lg text-lg tracking-tight">
             {totalBalance.toLocaleString(undefined, { minimumFractionDigits: 2 })}
          </div>
        </div>
        <div className="flex items-center gap-2 ml-4">
          <span className="text-[#4338ca]">ลูกค้าทั้งหมด</span>
          <span className="text-2xl text-[#6366f1]">{customers.length}</span>
        </div>
      </div>

      {/* Grid of Customers */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {customers.map((c, index) => {
          const detail = Storage.getCustomerDetails(c.id);
          const lastBalance = detail?.transactions[detail.transactions.length - 1]?.balance || 0;
          const totalItems = detail?.transactions.length || 0;
          const lastUpdate = detail?.updatedAt ? new Date(detail.updatedAt).toLocaleDateString('th-TH') : '-';

          return (
            <div 
              key={c.id} 
              className="bg-white rounded-[2rem] border border-gray-100 shadow-sm hover:shadow-xl transition-all duration-300 p-8 flex flex-col group relative"
            >
              <div className="flex justify-between items-start mb-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-[#6366f1] to-[#4338ca] flex items-center justify-center text-white font-bold text-lg shadow-md">
                    {index + 1}
                  </div>
                  <div className="overflow-hidden">
                    <h4 className="text-lg font-bold text-gray-800 truncate leading-tight group-hover:text-[#4338ca] transition-colors">{c.name}</h4>
                    <p className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">ID: {c.id}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button className="text-rose-400 hover:text-rose-600 transition-colors p-1"><svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" /></svg></button>
                  <button className="text-gray-300 hover:text-gray-500 transition-colors p-1"><svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg></button>
                </div>
              </div>
              <div className="border-t border-gray-50 pt-6 space-y-3 flex-grow">
                <div className="flex justify-between items-center text-sm"><span className="text-gray-400 font-medium">รายการทั้งหมด</span><span className="font-bold text-gray-700">{totalItems} รายการ</span></div>
                <div className="flex justify-between items-center text-sm"><span className="text-gray-400 font-medium">ยอดคงเหลือ</span><span className="font-bold text-[#16a34a] text-lg">{lastBalance.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span></div>
                <div className="flex justify-between items-center text-sm"><span className="text-gray-400 font-medium">อัปเดตล่าสุด</span><span className="font-bold text-gray-500">{lastUpdate}</span></div>
              </div>
              <button onClick={() => onSelectCustomer(c.id)} className="mt-8 w-full bg-[#f0fdf4] text-[#16a34a] hover:bg-[#dcfce7] py-3 rounded-2xl text-xs font-bold transition-all flex items-center justify-center gap-2 group/btn">
                <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
                ดูใบแสดงรายการ
              </button>
            </div>
          );
        })}
      </div>

      {/* OVERVIEW MODAL */}
      {showOverview && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/40 backdrop-blur-[2px] no-print animate-in fade-in duration-300">
          <div className="bg-white rounded-3xl w-full max-w-[1240px] max-h-[92vh] overflow-y-auto shadow-2xl animate-in zoom-in-95 duration-200">
            {/* Modal Header */}
            <div className="px-8 py-6 border-b border-gray-100 flex justify-between items-start sticky top-0 bg-white z-10">
              <div className="flex items-center gap-4">
                <img 
                  src={logo} 
                  alt="AlphaPatra Logo" 
                  className="h-10 w-10 object-contain rounded-lg shadow-sm"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = '/assets/logo/ap-logo.png';
                  }}
                />
                <div>
                  <h2 className="text-2xl font-bold text-gray-800">สรุปภาพรวมลูกค้าทั้งหมด</h2>
                  <p className="text-sm text-gray-400 font-medium">ดูมูลค่าเงินลงทุน กำไรสุทธิ และผลตอบแทน (%) ของทุกพอร์ตใน AlphaPatra</p>
                </div>
              </div>
              <button 
                onClick={() => setShowOverview(false)} 
                className="bg-gray-100 hover:bg-gray-200 text-gray-600 px-4 py-1.5 rounded-lg flex items-center gap-1.5 text-sm font-bold transition-all"
              >
                <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                ปิด
              </button>
            </div>

            <div className="p-8 space-y-8">
              {/* Summary Cards Row */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
                <div className="p-5 bg-[#f5f3ff] rounded-2xl border border-indigo-50 shadow-sm min-h-[140px] flex flex-col justify-between">
                  <p className="text-xs font-bold text-[#6366f1] uppercase tracking-wider">จำนวนลูกค้า</p>
                  <p className="text-3xl font-bold text-[#4338ca]">{customers.length}</p>
                </div>
                <div className="p-5 bg-[#f0fdf4] rounded-2xl border border-emerald-50 shadow-sm min-h-[140px] flex flex-col justify-between">
                  <p className="text-xs font-bold text-[#16a34a] uppercase tracking-wider">เงินทุนรวมทั้งหมด</p>
                  <p className="text-2xl font-bold text-[#14532D]">{totalFund.toLocaleString(undefined, { minimumFractionDigits: 2 })}</p>
                </div>
                <div className="p-5 bg-[#eff6ff] rounded-2xl border border-blue-50 shadow-sm min-h-[140px] flex flex-col justify-between">
                  <p className="text-xs font-bold text-[#3b82f6] uppercase tracking-wider">มูลค่าพอร์ตรวมล่าสุด</p>
                  <p className="text-2xl font-bold text-[#1e40af]">{totalBalance.toLocaleString(undefined, { minimumFractionDigits: 2 })}</p>
                </div>
                <div className="p-5 bg-[#fffbeb] rounded-2xl border border-amber-50 shadow-sm min-h-[140px] flex flex-col justify-between">
                  <p className="text-xs font-bold text-[#d97706] uppercase tracking-wider">กำไรรวมทั้งหมด</p>
                  <p className="text-2xl font-bold text-[#92400e]">{totalNetProfit.toLocaleString(undefined, { minimumFractionDigits: 2 })}</p>
                </div>
                <div className="p-5 bg-[#fff1f2] rounded-2xl border border-rose-50 shadow-sm min-h-[140px] flex flex-col justify-between">
                  <div className="flex justify-between items-start">
                    <p className="text-[10px] font-bold text-[#e11d48] uppercase tracking-wider">กำไรเฉพาะเดือนที่เลือก</p>
                    <div className="flex gap-1">
                      <select 
                        value={selectedMonth} 
                        onChange={(e) => setSelectedMonth(parseInt(e.target.value))}
                        className="bg-white/60 border border-rose-100 text-[9px] rounded px-1 py-0.5 outline-none font-bold"
                      >
                        {months.map((m, i) => <option key={i} value={i + 1}>{m}</option>)}
                      </select>
                      <select 
                        value={selectedYear} 
                        onChange={(e) => setSelectedYear(parseInt(e.target.value))}
                        className="bg-white/60 border border-rose-100 text-[9px] rounded px-1 py-0.5 outline-none font-bold"
                      >
                        {years.map(y => <option key={y} value={y}>{y}</option>)}
                      </select>
                    </div>
                  </div>
                  <div className="mt-2">
                    <p className="text-[10px] text-rose-300 font-bold mb-1">{months[selectedMonth - 1]} {selectedYear}</p>
                    <p className="text-2xl font-bold text-[#be123c]">{monthlyProfit.toLocaleString(undefined, { minimumFractionDigits: 2 })}</p>
                  </div>
                </div>
              </div>

              {/* Lower Section: Table and Chart */}
              <div className="flex flex-col lg:flex-row gap-6">
                {/* Table Left */}
                <div className="lg:w-[45%] bg-white rounded-2xl border border-gray-100 shadow-sm flex flex-col overflow-hidden relative">
                  <div className="p-5 border-b border-gray-50 flex justify-between items-center">
                    <h3 className="text-lg font-bold text-gray-700">ตารางภาพรวมลูกค้า</h3>
                    <span className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">เรียงตามลำดับการสร้าง</span>
                  </div>
                  <div className="overflow-auto max-h-[420px] custom-scrollbar">
                    <table className="w-full text-left border-collapse">
                      <thead className="bg-gray-50 sticky top-0 z-10">
                        <tr className="text-[10px] font-bold text-gray-400 uppercase tracking-wider border-b border-gray-100">
                          <th className="py-3 px-4">#</th>
                          <th className="py-3 px-4">ชื่อลูกค้า</th>
                          <th className="py-3 px-4 text-right">เงินทุนเริ่มต้น</th>
                          <th className="py-3 px-4 text-right">มูลค่าล่าสุด</th>
                          <th className="py-3 px-4 text-right">กำไรสุทธิ</th>
                          <th className="py-3 px-4 text-right">ผลตอบแทน %</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-50">
                        {allCustomerDetails.map((c, i) => {
                          const fund = c.transactions.reduce((s, t) => s + t.deposit, 0) || 0;
                          const last = c.transactions[c.transactions.length - 1]?.balance || 0;
                          const profit = last - fund;
                          const roi = fund > 0 ? (profit / fund) * 100 : 0;
                          return (
                            <tr key={c.id} className="hover:bg-gray-50/50 transition-colors text-xs">
                              <td className="py-3 px-4 text-gray-400 font-bold">{i + 1}</td>
                              <td className="py-3 px-4 font-bold text-gray-700 truncate max-w-[140px]">{c.name}</td>
                              <td className="py-3 px-4 text-right text-gray-600">{fund.toLocaleString(undefined, { minimumFractionDigits: 2 })}</td>
                              <td className="py-3 px-4 text-right text-gray-600 font-semibold">{last.toLocaleString(undefined, { minimumFractionDigits: 2 })}</td>
                              <td className={`py-3 px-4 text-right font-bold ${profit >= 0 ? 'text-[#16a34a]' : 'text-rose-500'}`}>{profit.toLocaleString(undefined, { minimumFractionDigits: 2 })}</td>
                              <td className="py-3 px-4 text-right font-bold text-[#6366f1]">{roi.toFixed(2)}%</td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                  {/* Watermark Logo */}
                  <img 
                    src={logo} 
                    alt="" 
                    className="absolute bottom-4 right-4 h-12 w-12 object-contain opacity-[0.05] pointer-events-none"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = '/assets/logo/ap-logo.png';
                    }}
                  />
                </div>

                {/* Chart Right */}
                <div className="lg:w-[55%] bg-white rounded-2xl border border-gray-100 shadow-sm p-6 flex flex-col relative">
                  <div className="flex justify-between items-center mb-6">
                    <h3 className="text-lg font-bold text-gray-700">Dashboard AlphaPatra</h3>
                    <span className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">ยอดล่าสุดต่อชื่อลูกค้า</span>
                  </div>
                  <div className="flex-grow min-h-[380px]">
                    <canvas ref={chartRef}></canvas>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Dashboard;
