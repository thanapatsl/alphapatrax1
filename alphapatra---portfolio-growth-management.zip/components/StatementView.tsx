
import React, { useState, useEffect, useRef } from 'react';
import { DetailedCustomer, Transaction } from '../types';
import { Storage } from '../utils/storage';
import { CSVUtils } from '../utils/csv';

declare const html2canvas: any;

interface StatementViewProps {
  customerId: string | null;
  onBack: () => void;
  onDelete: (id: string) => void;
}

const StatementView: React.FC<StatementViewProps> = ({ customerId, onBack, onDelete }) => {
  const [data, setData] = useState<DetailedCustomer | null>(null);
  const [showExportMenu, setShowExportMenu] = useState(false);
  const [isMobile, setIsMobile] = useState(window.innerWidth <= 768);
  const [logo, setLogo] = useState(Storage.getSystemLogo());
  const logoInputRef = useRef<HTMLInputElement>(null);
  const statementRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (customerId) setData(Storage.getCustomerDetails(customerId));
    const handleResize = () => setIsMobile(window.innerWidth <= 768);
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [customerId]);

  const save = (updated: DetailedCustomer) => {
    setData(updated);
    if (customerId) Storage.saveCustomerDetails(customerId, updated);
  };

  const handleMetaChange = (key: keyof DetailedCustomer, val: string) => {
    if (!data || isMobile) return;
    save({ ...data, [key]: val });
  };

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const base64 = event.target?.result as string;
      Storage.saveSystemLogo(base64);
      setLogo(base64);
    };
    reader.readAsDataURL(file);
  };

  const calculateBalances = (transactions: Transaction[]) => {
    let current = 0;
    return transactions.map((t) => {
      const base = current;
      const profitAmount = base * (t.profitPercent / 100);
      const rowBalance = base + t.deposit - t.withdraw + profitAmount;
      current = rowBalance;
      return { ...t, balance: rowBalance };
    });
  };

  const updateTransaction = (idx: number, field: keyof Transaction, val: string | number) => {
    if (!data || isMobile) return;
    const newTx = [...data.transactions];
    newTx[idx] = { ...newTx[idx], [field]: val };
    save({ ...data, transactions: calculateBalances(newTx) });
  };

  const addRow = () => {
    if (!data || isMobile) return;
    const lastBal = data.transactions.length > 0 ? data.transactions[data.transactions.length - 1].balance : 0;
    const newRow: Transaction = { id: Date.now().toString(), date: new Date().toISOString().split('T')[0], detail: '', deposit: 0, withdraw: 0, profitPercent: 0, channel: '-', balance: lastBal };
    save({ ...data, transactions: [...data.transactions, newRow] });
  };

  const removeRow = (idx: number) => {
    if (!data || isMobile || data.transactions.length <= 1) return;
    save({ ...data, transactions: calculateBalances(data.transactions.filter((_, i) => i !== idx)) });
  };

  const handleExportImage = async (format: 'png' | 'jpeg') => {
    if (!statementRef.current) return;
    setShowExportMenu(false);
    const canvas = await html2canvas(statementRef.current, { scale: 3, useCORS: true, backgroundColor: '#ffffff' });
    const link = document.createElement('a');
    link.download = `alphapatra_statement_${data?.name}_${Date.now()}.${format}`;
    link.href = canvas.toDataURL(`image/${format}`, format === 'jpeg' ? 0.95 : undefined);
    link.click();
  };

  const handleExportCSV = () => {
    if (!data) return;
    const csv = CSVUtils.generateCSV([{ customer_id: data.id, customer_name: data.name, transactions: data.transactions }]);
    CSVUtils.downloadFile(csv, `statement_${data.name}.csv`);
    setShowExportMenu(false);
  };

  const handleImportCSV = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !data) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      const rows = CSVUtils.parseCSV(text);
      if (rows.length < 2) return;
      const newTransactions: Transaction[] = rows.slice(1).map(row => ({
        id: Math.random().toString(36).substr(2, 9),
        date: row[2],
        deposit: parseFloat(row[3]) || 0,
        withdraw: parseFloat(row[4]) || 0,
        profitPercent: parseFloat(row[5]) || 0,
        channel: row[6],
        detail: row[7],
        balance: 0
      }));
      save({ ...data, transactions: calculateBalances(newTransactions) });
    };
    reader.readAsText(file);
  };

  if (!data) return <div className="p-10 text-center text-[#6B7280]">กำลังโหลดข้อมูลพอร์ตลงทุน...</div>;

  const totalFund = data.transactions.reduce((sum, t) => sum + t.deposit, 0);
  const finalBalance = data.transactions[data.transactions.length - 1]?.balance || 0;
  const totalProfit = finalBalance - totalFund;
  const profitSplit = totalProfit > 0 ? totalProfit / 2 : 0;
  const clientNet = totalFund + profitSplit;

  return (
    <div className="max-w-[1200px] mx-auto p-4 space-y-6 animate-in fade-in duration-500">
      {/* Top Header Navigation */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4 flex flex-col md:flex-row items-center justify-between no-print gap-4">
        <div className="flex items-center gap-4">
          <button onClick={onBack} className="bg-[#334155] text-white px-4 py-2 rounded-lg flex items-center text-sm font-medium hover:bg-[#1e293b] transition-colors">
            <svg className="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" /></svg>
            ← กลับหน้าหลัก
          </button>
          <div className="flex items-center gap-3">
            <div 
              onClick={() => !isMobile && logoInputRef.current?.click()}
              className="h-10 w-10 flex items-center justify-center cursor-pointer hover:opacity-80 transition-opacity"
              title="คลิกเพื่อเปลี่ยนโลโก้"
            >
              <img 
                src={logo} 
                alt="AlphaPatra" 
                className="h-full w-full object-contain rounded-lg"
                onError={(e) => {
                  (e.target as HTMLImageElement).src = '/assets/logo/ap-logo.png';
                }}
              />
              <input type="file" ref={logoInputRef} className="hidden" accept="image/*" onChange={handleLogoUpload} />
            </div>
            <div>
              <h2 className="text-lg font-semibold text-gray-800 leading-tight">{data.name}</h2>
              <p className="text-xs text-gray-400">ใบแสดงรายการปั้นพอร์ต</p>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button className="bg-[#4f46e5] text-white px-4 py-2 rounded-lg flex items-center text-sm font-medium hover:bg-[#4338ca] transition-colors">
            <svg className="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" /></svg>
            เปลี่ยนชื่อ
          </button>
          <button onClick={() => onDelete(data.id)} className="bg-[#dc2626] text-white px-4 py-2 rounded-lg flex items-center text-sm font-medium hover:bg-[#b91c1c] transition-colors">
            <svg className="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
            ลบลูกค้า
          </button>
        </div>
      </div>

      <div ref={statementRef} className="space-y-6">
        {/* Report Header Card */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-8">
          <div className="flex flex-col md:flex-row justify-between items-start gap-6">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-[#061e33] rounded-lg flex items-center justify-center p-2 shadow-sm">
                <img 
                  src={logo} 
                  alt="Logo" 
                  className="w-full h-full object-contain"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = '/assets/logo/ap-logo.png';
                  }}
                />
              </div>
              <h1 className="text-2xl font-bold text-gray-800">ใบแสดงรายการปั้นพอร์ต</h1>
            </div>
            <div className="flex items-center gap-2 no-print relative">
              <button onClick={() => setShowExportMenu(!showExportMenu)} className="bg-[#4f46e5] text-white px-6 py-2 rounded-lg flex items-center text-sm font-semibold shadow-md hover:bg-[#4338ca] transition-colors">
                <svg className="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
                ส่งออก
                <svg className="h-4 w-4 ml-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" /></svg>
              </button>
              {showExportMenu && (
                <div className="absolute right-0 top-12 w-48 bg-white border border-gray-100 rounded-lg shadow-xl z-50 overflow-hidden py-1">
                  <button onClick={() => handleExportImage('png')} className="w-full text-left px-4 py-2 text-sm hover:bg-gray-50">บันทึกเป็น PNG</button>
                  <button onClick={() => handleExportImage('jpeg')} className="w-full text-left px-4 py-2 text-sm hover:bg-gray-50">บันทึกเป็น JPEG</button>
                  <button onClick={handleExportCSV} className="w-full text-left px-4 py-2 text-sm hover:bg-gray-50">Export CSV</button>
                  <button onClick={() => window.print()} className="w-full text-left px-4 py-2 text-sm hover:bg-gray-50 border-t">Print PDF</button>
                </div>
              )}
              <label htmlFor="st-import" className="bg-[#16a34a] text-white px-6 py-2 rounded-lg flex items-center text-sm font-semibold shadow-md hover:bg-[#15803d] transition-colors cursor-pointer">
                <svg className="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" /></svg>
                Import CSV (ลูกค้านี้)
              </label>
              <input type="file" id="st-import" className="sr-only" accept=".csv" onChange={handleImportCSV} />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-10">
            <div className="space-y-6">
              <div>
                <label className="text-xs font-semibold text-gray-500 uppercase block mb-2">เจ้าของเงินลงทุน</label>
                <input type="text" value={data.name} readOnly={isMobile} onChange={(e) => handleMetaChange('name', e.target.value)} className="w-full bg-white border border-gray-200 rounded-lg p-3 text-sm font-medium focus:ring-1 focus:ring-[#14532D] outline-none" />
              </div>
              <div>
                <label className="text-xs font-semibold text-gray-500 uppercase block mb-2">ผู้ดูแลพอร์ตหุ้น</label>
                <input type="text" value="นายธนภัทร ศาลาvาม (อัลฟ่าภัทร AlphaPatra)" readOnly className="w-full bg-gray-50 border border-gray-200 rounded-lg p-3 text-sm font-medium text-gray-600 outline-none" />
              </div>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="bg-[#fef2f2] border border-[#fee2e2] p-5 rounded-lg flex flex-col justify-center">
                <span className="text-xs text-gray-500 font-semibold uppercase mb-2">เงินลงทุนเริ่มต้น (รวมฝากเงินทั้งหมด)</span>
                <p className="text-2xl font-bold text-[#dc2626]">฿ {totalFund.toLocaleString(undefined, { minimumFractionDigits: 2 })}</p>
              </div>
              <div className="bg-[#f0fdf4] border border-[#dcfce7] p-5 rounded-lg flex flex-col justify-center">
                <span className="text-xs text-gray-500 font-semibold uppercase mb-2">สรุปยอดเงินล่าสุด</span>
                <p className="text-2xl font-bold text-[#16a34a]">฿ {finalBalance.toLocaleString(undefined, { minimumFractionDigits: 2 })}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Transaction Section */}
        <div className="bg-[#f0fdf4] rounded-xl shadow-sm border border-emerald-100 overflow-hidden">
          <div className="p-6 flex flex-col md:flex-row justify-between items-center gap-4">
            <h3 className="text-lg font-bold text-[#065f46]">รายการธุรกรรมปั้นพอร์ต</h3>
            {!isMobile && (
              <button onClick={addRow} className="bg-[#16a34a] text-white px-5 py-2 rounded-lg flex items-center text-sm font-bold shadow-sm hover:bg-[#15803d] transition-colors no-print">
                <svg className="h-5 w-5 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" /></svg>
                เพิ่มรายการ
              </button>
            )}
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left min-w-[1000px]">
              <thead className="bg-[#14532D] text-white">
                <tr className="text-[11px] font-bold uppercase tracking-wider">
                  <th className="p-4 border-b border-emerald-900">วันที่</th>
                  <th className="p-4 border-b border-emerald-900 text-center">ฝากเงิน</th>
                  <th className="p-4 border-b border-emerald-900 text-center">ถอนเงิน</th>
                  <th className="p-4 border-b border-emerald-900 text-center">กำไร %</th>
                  <th className="p-4 border-b border-emerald-900 text-center">กำไร จำนวนเงิน</th>
                  <th className="p-4 border-b border-emerald-900">ช่องทาง</th>
                  <th className="p-4 border-b border-emerald-900 text-right">ยอดคงเหลือ</th>
                  <th className="p-4 border-b border-emerald-900">รายละเอียด</th>
                  <th className="p-4 border-b border-emerald-900 text-center no-print">จัดการ</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-100">
                {data.transactions.map((tx, idx) => {
                  const prevBal = idx === 0 ? 0 : data.transactions[idx - 1].balance;
                  const profitAmt = prevBal * (tx.profitPercent / 100);
                  return (
                    <tr key={tx.id} className="hover:bg-gray-50/50 transition-colors">
                      <td className="p-2">
                        <input type="date" value={tx.date} readOnly={isMobile} onChange={(e) => updateTransaction(idx, 'date', e.target.value)} className="w-full text-xs bg-transparent border-none focus:ring-0 p-1" />
                      </td>
                      <td className="p-2">
                        <div className="flex flex-col items-center">
                          <input type="number" value={tx.deposit} readOnly={isMobile} onChange={(e) => updateTransaction(idx, 'deposit', parseFloat(e.target.value) || 0)} className="w-32 text-center text-sm font-bold bg-white border border-gray-200 rounded p-1 focus:ring-1 focus:ring-emerald-500" />
                          <span className="text-[10px] text-blue-600 mt-1">{tx.deposit.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                        </div>
                      </td>
                      <td className="p-2">
                        <div className="flex flex-col items-center">
                          <input type="number" value={tx.withdraw} readOnly={isMobile} onChange={(e) => updateTransaction(idx, 'withdraw', parseFloat(e.target.value) || 0)} className="w-32 text-center text-sm font-bold bg-white border border-gray-200 rounded p-1 focus:ring-1 focus:ring-rose-500" />
                          <span className={`text-[10px] mt-1 ${tx.withdraw > 0 ? 'text-rose-500 font-medium' : 'text-gray-400'}`}>
                            {tx.withdraw.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                          </span>
                        </div>
                      </td>
                      <td className="p-2">
                         <div className="flex flex-col items-center">
                          <input type="number" step="0.01" value={tx.profitPercent} readOnly={isMobile} onChange={(e) => updateTransaction(idx, 'profitPercent', parseFloat(e.target.value) || 0)} className="w-20 text-center text-sm font-bold bg-white border border-gray-200 rounded p-1" />
                          <span className="text-[10px] text-gray-400 mt-1">{tx.profitPercent}%</span>
                         </div>
                      </td>
                      <td className="p-2 text-center text-sm font-bold text-[#16a34a]">
                        <div className="w-24 mx-auto border-b border-gray-100 pb-1">
                          {profitAmt !== 0 ? profitAmt.toLocaleString(undefined, { minimumFractionDigits: 2 }) : '-'}
                        </div>
                      </td>
                      <td className="p-2">
                        <input type="text" value={tx.channel} readOnly={isMobile} onChange={(e) => updateTransaction(idx, 'channel', e.target.value)} className="w-24 text-sm bg-white border border-gray-200 rounded p-1" />
                      </td>
                      <td className="p-4 text-right text-sm font-bold text-[#16a34a]">
                        {tx.balance.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                      </td>
                      <td className="p-2">
                        <input type="text" value={tx.detail} readOnly={isMobile} onChange={(e) => updateTransaction(idx, 'detail', e.target.value)} className="w-full text-xs bg-white border border-gray-200 rounded p-1" placeholder="ระบุรายละเอียด..." />
                      </td>
                      <td className="p-2 text-center no-print">
                        {!isMobile && (
                          <div className="flex justify-center items-center gap-2">
                            <button onClick={addRow} className="text-purple-400 hover:text-purple-600">
                               <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" /></svg>
                            </button>
                            <button onClick={() => removeRow(idx)} className="text-gray-300 hover:text-rose-500">
                               <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                            </button>
                          </div>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* AlphaProfit Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 relative">
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-8">
            <h4 className="text-lg font-bold text-gray-800 mb-2 flex items-center">
              💰 AlphaProfit – คำนวณส่วนแบ่งกำไร
            </h4>
            <p className="text-xs text-gray-400 mb-6 uppercase tracking-wider">AlphaPatra Growth Analysis</p>
            
            <div className="space-y-6">
              <div>
                <label className="text-xs font-bold text-gray-500 flex items-center gap-2 mb-2">
                   📊 ยอดรวมทั้งหมด (หลังปั้นพอร์ต)
                </label>
                <input type="text" value={finalBalance.toFixed(2)} readOnly className="w-full bg-gray-50 border border-gray-100 rounded-lg p-3 text-lg font-bold text-gray-700 outline-none" />
              </div>
              <div>
                <label className="text-xs font-bold text-gray-500 flex items-center gap-2 mb-2">
                   💵 เงินทุนลูกค้า (ต้นทุนเริ่มต้น)
                </label>
                <input type="text" value={totalFund.toFixed(2)} readOnly className="w-full bg-gray-50 border border-gray-100 rounded-lg p-3 text-lg font-bold text-gray-700 outline-none" />
              </div>
              <p className="text-[10px] text-emerald-600 font-medium italic">✓ ระบบอัปเดตผลตอบแทนให้ทันทีเมื่อมีการเปลี่ยนแปลงข้อมูลพอร์ต</p>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-8 relative">
            <div className="border border-gray-100 rounded-xl p-6 bg-white shadow-sm">
              <h4 className="text-lg font-bold text-gray-800 mb-6 flex items-center justify-center">
                📋 สรุปผลการแบ่งกำไร
              </h4>
              <div className="space-y-4 text-sm">
                <div className="flex justify-between items-center py-2 border-b border-gray-50">
                  <span className="text-gray-500">ยอดรวมทั้งหมด</span>
                  <span className="font-bold text-gray-800">{finalBalance.toLocaleString(undefined, { minimumFractionDigits: 2 })} บาท</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-gray-50">
                  <span className="text-gray-500">เงินทุนลูกค้า</span>
                  <span className="font-bold text-gray-800">{totalFund.toLocaleString(undefined, { minimumFractionDigits: 2 })} บาท</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-gray-50">
                  <span className="text-gray-500">กำไรสุทธิ</span>
                  <span className="font-bold text-[#16a34a]">{totalProfit.toLocaleString(undefined, { minimumFractionDigits: 2 })} บาท</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-gray-50">
                  <span className="text-gray-500">แบ่งกำไรคนละ (50/50)</span>
                  <span className="font-bold text-purple-600">{profitSplit.toLocaleString(undefined, { minimumFractionDigits: 2 })} บาท</span>
                </div>
                
                <div className="mt-8 pt-6 border-t border-gray-100">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-gray-800 font-bold flex items-center gap-2">
                       💎 ผู้ว่าจ้างได้รับสุทธิ
                    </span>
                    <span className="text-2xl font-bold text-[#16a34a]">{clientNet.toLocaleString(undefined, { minimumFractionDigits: 2 })} บาท</span>
                  </div>
                  <div className="flex justify-between items-center text-xs text-gray-400 font-medium">
                    <span>ส่วนของผู้ว่าจ้าง</span>
                    <span>{profitSplit.toLocaleString(undefined, { minimumFractionDigits: 2 })} บาท</span>
                  </div>
                  <div className="flex justify-between items-center text-xs text-gray-400 font-medium">
                    <span>ส่วนของผู้ดูแลพอร์ต</span>
                    <span>{profitSplit.toLocaleString(undefined, { minimumFractionDigits: 2 })} บาท</span>
                  </div>
                </div>
              </div>
            </div>
            {/* Watermark logo */}
            <img 
              src={logo} 
              alt="" 
              className="absolute bottom-2 right-2 h-16 w-16 object-contain opacity-[0.03] pointer-events-none"
              onError={(e) => {
                (e.target as HTMLImageElement).src = '/assets/logo/ap-logo.png';
              }}
            />
          </div>
        </div>

        {/* Brand Footer */}
        <div className="text-right text-[10px] leading-relaxed no-print pb-10 flex flex-col items-end gap-1">
          <div className="flex items-center gap-2 mb-2">
            <img src={logo} className="h-6 w-6 object-contain opacity-50 grayscale" alt="" onError={(e) => (e.target as HTMLImageElement).src = '/assets/logo/ap-logo.png'} />
            <p className="font-bold text-[#14532D]">อัลฟ่าภัทร AlphaPatra</p>
          </div>
          <p className="text-gray-400">เลขที่ 85/1 หมู่ 12 ตำบลสะแก</p>
          <p className="text-gray-400">อำเภอสตึก จังหวัดบุรีรัมย์ 31150</p>
          <p className="text-blue-600 font-bold">(0863019724)</p>
        </div>
      </div>
    </div>
  );
};

export default StatementView;
