
export interface Transaction {
  id: string;
  date: string;
  detail: string;
  deposit: number;
  withdraw: number;
  profitPercent: number;
  channel: string;
  balance: number;
}

export interface DetailedCustomer {
  id: string;
  name: string;
  reportTitle: string;
  bankName: string;
  accountNo: string;
  transactions: Transaction[];
  createdAt: string;
  updatedAt: string;
}

export interface CustomerIndexItem {
  id: string;
  name: string;
  createdAt: string;
  updatedAt: string;
}

export type Page = 'dashboard' | 'statement';
