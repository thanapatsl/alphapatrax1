
import { Transaction, DetailedCustomer } from '../types';

export const CSVUtils = {
  generateCSV(data: { customer_id: string; customer_name: string; transactions: Transaction[] }[]): string {
    const header = 'customer_id,customer_name,date,deposit,withdraw,profit_percent,channel,detail';
    const rows = data.flatMap(item => 
      item.transactions.map(t => [
        item.customer_id,
        `"${item.customer_name.replace(/"/g, '""')}"`,
        t.date,
        t.deposit,
        t.withdraw,
        t.profitPercent,
        `"${t.channel.replace(/"/g, '""')}"`,
        `"${t.detail.replace(/"/g, '""')}"`
      ].join(','))
    );
    return [header, ...rows].join('\r\n');
  },

  parseCSV(text: string): any[] {
    // Handle BOM
    const cleanText = text.replace(/^\uFEFF/, '');
    const rows: any[] = [];
    let currentRow: string[] = [];
    let currentField = '';
    let inQuotes = false;

    for (let i = 0; i < cleanText.length; i++) {
      const char = cleanText[i];
      const next = cleanText[i + 1];

      if (char === '"' && inQuotes && next === '"') {
        currentField += '"';
        i++;
      } else if (char === '"') {
        inQuotes = !inQuotes;
      } else if (char === ',' && !inQuotes) {
        currentRow.push(currentField);
        currentField = '';
      } else if ((char === '\r' || char === '\n') && !inQuotes) {
        if (currentField || currentRow.length > 0) {
          currentRow.push(currentField);
          rows.push(currentRow);
          currentRow = [];
          currentField = '';
        }
        if (char === '\r' && next === '\n') i++;
      } else {
        currentField += char;
      }
    }
    if (currentField || currentRow.length > 0) {
      currentRow.push(currentField);
      rows.push(currentRow);
    }
    return rows;
  },

  downloadFile(content: string, filename: string) {
    const blob = new Blob(['\uFEFF' + content], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', filename);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }
};
