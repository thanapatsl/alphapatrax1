
import { CustomerIndexItem, DetailedCustomer, Transaction } from '../types';

const KEYS = {
  INDEX: 'alphapatra_v2_customers_index',
  CUSTOMER_PREFIX: 'alphapatra_v2_customer_',
  SYSTEM_LOGO: 'alphapatra_v2_system_logo',
};

export const Storage = {
  getCustomersIndex(): CustomerIndexItem[] {
    const data = localStorage.getItem(KEYS.INDEX);
    return data ? JSON.parse(data) : [];
  },

  saveCustomersIndex(index: CustomerIndexItem[]) {
    localStorage.setItem(KEYS.INDEX, JSON.stringify(index));
  },

  getCustomerDetails(id: string): DetailedCustomer | null {
    const data = localStorage.getItem(KEYS.CUSTOMER_PREFIX + id);
    return data ? JSON.parse(data) : null;
  },

  saveCustomerDetails(id: string, details: DetailedCustomer) {
    localStorage.setItem(KEYS.CUSTOMER_PREFIX + id, JSON.stringify(details));
    
    const index = this.getCustomersIndex();
    const itemIndex = index.findIndex(item => item.id === id);
    const now = new Date().toISOString();
    
    if (itemIndex > -1) {
      index[itemIndex] = { ...index[itemIndex], name: details.name, updatedAt: now };
    } else {
      index.push({ id, name: details.name, createdAt: now, updatedAt: now });
    }
    this.saveCustomersIndex(index);
  },

  deleteCustomer(id: string) {
    localStorage.removeItem(KEYS.CUSTOMER_PREFIX + id);
    const index = this.getCustomersIndex();
    this.saveCustomersIndex(index.filter(item => item.id !== id));
  },

  getSystemLogo(): string {
    return localStorage.getItem(KEYS.SYSTEM_LOGO) || '/assets/logo/ap-logo.png';
  },

  saveSystemLogo(base64: string) {
    localStorage.setItem(KEYS.SYSTEM_LOGO, base64);
  },

  createEmptyCustomer(id: string, name: string): DetailedCustomer {
    const now = new Date().toISOString();
    return {
      id,
      name,
      reportTitle: 'ใบแสดงรายการปั้นพอร์ต',
      bankName: '',
      accountNo: '',
      transactions: [{
        id: 'initial-' + Date.now(),
        date: new Date().toISOString().split('T')[0],
        detail: 'เปิดพอร์ตเริ่มต้น',
        deposit: 0,
        withdraw: 0,
        profitPercent: 0,
        channel: '-',
        balance: 0
      }],
      createdAt: now,
      updatedAt: now,
    };
  },

  seedInitialData() {
    const index = this.getCustomersIndex();
    if (index.length === 0) {
      const firstCustomer = this.createEmptyCustomer('1', 'ลูกค้าตัวอย่าง');
      this.saveCustomerDetails('1', firstCustomer);
    }
  },

  bulkImport(data: Record<string, DetailedCustomer>) {
    Object.entries(data).forEach(([id, details]) => {
      this.saveCustomerDetails(id, details);
    });
  }
};
